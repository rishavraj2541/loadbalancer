# Kong Gateway Helm Docs Samples
This directory contains sample values files written in support of official [docs.konghq.com](https://docs.konghq.com/gateway/3.0.x/install-and-run/) workflows.

## Disclaimer
The samples here are published for educational purposes and should not be considered production ready as-is.