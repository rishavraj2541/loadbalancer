# GWAPI experimental CRDs subchart

This sub-chart contains Gateway API experimental CRDs, allowing users to control whether to install the CRDs.

