# KIC CRDs subchart

This sub-chart contains Kong Ingress Controller (KIC)'s CRDs, allowing users to control whether to install them.

