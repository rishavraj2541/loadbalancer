# GWAPI standard CRDs subchart

This sub-chart contains Gateway API standard CRDs, allowing users to control whether to install the CRDs.

